# Trines kaninguide

Dette prosjektet bygger APK automatisk i GitHub Actions uten Expo-token.

## Slik virker det
- Hver gang du pusher til `main`, starter GitHub Actions automatisk.
- APK-filen blir lagt som artifact i Actions-kjøringen.

## Hvor finner du APK
- Gå til `Actions`
- Åpne siste kjøring av `Build APK`
- Last ned artifact: `trines-kaninguide-apk`

## Viktig
I GitHub må filene ligge med mapper akkurat som i denne zip-filen.
Ikke flytt `index.html`, `styles.css` eller `app.js` ut av `app/src/main/assets/`.
