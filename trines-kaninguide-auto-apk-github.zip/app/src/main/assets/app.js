const breeds = [
  {
    name: "Hermelin",
    size: "Liten",
    weight: "ca. 0,8–1,3 kg",
    temperament: "Våken, livlig og ofte kvikk.",
    colors: ["Hvit rødøyd", "Hvit blåøyd", "Flere godkjente farger avhengig av linje"],
    reproduction: "Kjønnsmoden tidlig. Små kull er vanlig sammenlignet med større raser. Drektighet hos kanin er normalt rundt 30–33 dager.",
    pros: ["Tar lite plass", "Lett å håndtere fysisk", "Populær som kjæledyr og utstilling"],
    cons: ["Kan være mer nervøs enn tyngre raser", "Ikke ideell for små barn uten rolig håndtering", "Små kull sammenlignet med større raser"],
    needs: ["Rolig miljø", "God sosialisering", "Romslig binge", "Mye høy og daglig aktivitet"],
    bestFor: "Passer for dem som vil ha en liten kanin med mye personlighet."
  },
  {
    name: "Dvergvedder",
    size: "Liten",
    weight: "ca. 1,4–1,9 kg",
    temperament: "Ofte roligere og sosial enn mange andre små raser.",
    colors: ["Viltgrå", "Svart", "Blå", "Hvit", "Madagaskar", "Kappe og flere varianter"],
    reproduction: "Tidlig kjønnsmodning. Vanligvis moderate kull. Drektighet normalt 30–33 dager.",
    pros: ["Svært populær familiekanin", "Ofte tillitsfull", "Fin størrelse for både inne og ute"],
    cons: ["Hengeører kan kreve ekstra øresjekk", "Kan lett bli overvektig", "Tett pels krever oppfølging i røyteperioder"],
    needs: ["Daglig tilsyn av ører og klør", "Kontroll på vekt", "God plass til hopping", "Selskap av kompatibel kanin"],
    bestFor: "God allround-rase for mange hjem."
  },
  {
    name: "Løvehodekanin",
    size: "Liten",
    weight: "ca. 1,2–1,7 kg",
    temperament: "Søt, kvikk og ofte nysgjerrig.",
    colors: ["Hvit", "Svart", "Blå", "Viltfarget", "Japaner og flere"],
    reproduction: "Som liten rase blir den tidlig kjønnsmoden. Kullstørrelse ofte mindre enn hos store raser.",
    pros: ["Veldig dekorativ", "Populær som selskapskanin", "Mange fine fargevarianter"],
    cons: ["Mer pelsstell rundt manke", "Kan få tover", "Noen linjer kan ha tann- eller bittutfordringer"],
    needs: ["Jevnlig pelsstell", "Ekstra kontroll rundt øyne og bakpart", "Fiberrikt kosthold for tannslitasje"],
    bestFor: "Passer for dem som vil ha en liten, flott rase og tåler litt mer stell."
  },
  {
    name: "Rex",
    size: "Mellomstor",
    weight: "ca. 3–4,5 kg",
    temperament: "Rolig, vennlig og ofte lett å få tam.",
    colors: ["Castor", "Svart", "Blå", "Hvit", "Havanna", "Otter"],
    reproduction: "Moderate kull. Størrelsen gjør ofte avl og oppfostring mer robust enn hos de minste rasene.",
    pros: ["Spesiell fløyelsmyk pels", "Ofte rolig gemytt", "Fin størrelse for håndtering"],
    cons: ["Pelsen tåler ikke hard håndtering like godt", "Kan få trykksår på dårlig underlag", "Ikke like værhard som grovere pels"],
    needs: ["Tørt og rent underlag", "God isolasjon ute vinterstid", "Rolig håndtering av pels"],
    bestFor: "Passer for dem som vil ha en middels stor, rolig rase."
  },
  {
    name: "New Zealand",
    size: "Stor",
    weight: "ca. 4–5,5 kg",
    temperament: "Rolig, robust og matglad.",
    colors: ["Hvit", "Rød", "Svart"],
    reproduction: "Kjent for god reproduksjon og jevne kull. Større kull er vanligere enn hos små raser.",
    pros: ["Robust rase", "God morsegenskap i mange linjer", "Passer godt for dem som vil ha større kanin"],
    cons: ["Krever mer plass", "Spiser mer", "Tyngre å håndtere for barn"],
    needs: ["Større binge", "Godt underlag for poter", "Mer fôr og høyforbruk"],
    bestFor: "God for dem som vil ha en stor, stødig kanin eller jobber med avl i litt større skala."
  },
  {
    name: "Fransk vedder",
    size: "Stor",
    weight: "ca. 5–7 kg",
    temperament: "Mild, tung og ofte rolig.",
    colors: ["Viltgrå", "Jerngrå", "Blå", "Svart", "Gul og flere"],
    reproduction: "Store hunner kan få gode kull, men rasen krever mer plass og mer oppfølging rundt hold og beinhelse.",
    pros: ["Svært rolig uttrykk", "Imponerende størrelse", "Ofte trivelig selskapskanin"],
    cons: ["Trenger mye plass", "Hengeører krever jevnlig kontroll", "Kan få belastning på ledd hvis den blir for tung"],
    needs: ["Romslig og tørt opphold", "Stabil temperatur", "Kontroll på vekt og negler", "Stor utegård"],
    bestFor: "Best for dem som har god plass og vil ha en stor, rolig rase."
  },
  {
    name: "Belgisk hare",
    size: "Mellomstor til stor",
    weight: "ca. 3–4 kg",
    temperament: "Svært aktiv, følsom og elegant.",
    colors: ["Rødbrun harefarget"],
    reproduction: "Kan avles fint, men rasen er ofte mer krevende i temperament og miljø enn tyngre, roligere raser.",
    pros: ["Svært vakker og atletisk", "Høy aktivitet og spenstig uttrykk", "Spennende rase for erfarne"],
    cons: ["Kan være stresset", "Mindre egnet for små barn", "Krever mye plass og ro rundt seg"],
    needs: ["Lang løpeflate", "Lite stress", "Skjulesteder", "Tålmodig håndtering"],
    bestFor: "Passer best for dem som vil ha en aktiv og elegant rase, og som har erfaring."
  },
  {
    name: "Flandernkjempe",
    size: "Svært stor",
    weight: "ca. 6–10+ kg",
    temperament: "Rolig kjempe, ofte mild og tregere i tempo.",
    colors: ["Stålfarget", "Sand", "Svart", "Blå", "Lys grå"],
    reproduction: "Større kropp gir ofte rom for større kull, men alt rundt paring, binger og oppvekst krever mer plass og kraftigere utstyr.",
    pros: ["Imponerende størrelse", "Ofte rolig gemytt", "Kan bli svært tam"],
    cons: ["Krever mye plass og mye fôr", "Tyngre belastning på poter og ledd", "Ikke praktisk i små anlegg"],
    needs: ["Svært romslig opphold", "Godt underlag", "Vektkontroll", "Ekstra robuste matskåler og hus"],
    bestFor: "For dem som har god plass og virkelig ønsker en stor rase."
  }
];

const sizes = ["Alle", "Liten", "Mellomstor", "Stor"];
let currentSize = "Alle";
let currentQuery = "";

const filterRow = document.getElementById("filterRow");
const breedList = document.getElementById("breedList");
const searchInput = document.getElementById("searchInput");

function renderFilters() {
  filterRow.innerHTML = "";
  sizes.forEach((size) => {
    const btn = document.createElement("button");
    btn.className = "filter-btn" + (size === currentSize ? " active" : "");
    btn.textContent = size;
    btn.onclick = () => {
      currentSize = size;
      renderFilters();
      renderBreeds();
    };
    filterRow.appendChild(btn);
  });
}

function list(items) {
  return `<ul class="list">${items.map((item) => `<li>${item}</li>`).join("")}</ul>`;
}

function renderBreeds() {
  const q = currentQuery.trim().toLowerCase();
  const filtered = breeds.filter((breed) => {
    const matchesSize = currentSize === "Alle" || breed.size.toLowerCase().includes(currentSize.toLowerCase());
    const haystack = [
      breed.name,
      breed.temperament,
      breed.colors.join(" "),
      breed.bestFor
    ].join(" ").toLowerCase();
    const matchesQuery = !q || haystack.includes(q);
    return matchesSize && matchesQuery;
  });

  breedList.innerHTML = filtered.map((breed) => `
    <section class="breed-card">
      <div class="breed-header">
        <div>
          <h2 class="breed-name">${breed.name}</h2>
          <div class="meta">${breed.weight}</div>
        </div>
        <div class="badge">${breed.size}</div>
      </div>

      <div class="section">
        <h3>Temperament</h3>
        <div class="body-text">${breed.temperament}</div>
      </div>

      <div class="section">
        <h3>Vanlige farger</h3>
        <div class="chips">
          ${breed.colors.map((color) => `<span class="chip">${color}</span>`).join("")}
        </div>
      </div>

      <div class="section">
        <h3>Reproduksjon</h3>
        <div class="body-text">${breed.reproduction}</div>
      </div>

      <div class="two-col">
        <div class="box good">
          <h3>Fordeler</h3>
          ${list(breed.pros)}
        </div>
        <div class="box bad">
          <h3>Ulemper</h3>
          ${list(breed.cons)}
        </div>
      </div>

      <div class="section">
        <h3>Hva rasen krever</h3>
        ${list(breed.needs)}
      </div>

      <div class="section">
        <h3>Passer best for</h3>
        <div class="body-text">${breed.bestFor}</div>
      </div>
    </section>
  `).join("");
}

searchInput.addEventListener("input", (e) => {
  currentQuery = e.target.value;
  renderBreeds();
});

renderFilters();
renderBreeds();
